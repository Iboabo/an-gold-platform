import { useState, useEffect, useRef, useCallback } from "react";

// ═══════════════════ GOLD PRICE ═══════════════════
function useGoldPrice() {
  const [price, setPrice] = useState(3347);
  const [change, setChange] = useState(0);
  const [pct, setPct] = useState(0);
  const [high, setHigh] = useState(3365);
  const [low, setLow] = useState(3312);
  const openRef = useRef(3347);
  const [candles, setCandles] = useState(() => {
    const arr = []; let p = 3200;
    for (let i = 79; i >= 0; i--) {
      p += (Math.random() - 0.488) * 20; p = Math.max(3050, Math.min(3600, p));
      const o = p + (Math.random() - 0.5) * 10;
      arr.push({ o: +o.toFixed(1), c: +p.toFixed(1), h: +(Math.max(p,o)+Math.random()*12).toFixed(1), l: +(Math.min(p,o)-Math.random()*12).toFixed(1) });
    }
    return arr;
  });

  const fetchPrice = useCallback(async () => {
    try {
      const r = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent("https://data-asg.goldprice.org/dbXRates/USD")}`, { cache: "no-store" });
      const d = await r.json();
      const xau = JSON.parse(d.contents)?.items?.[0]?.xauPrice;
      if (xau && xau > 1000) {
        setPrice(prev => {
          const ch = +(xau - openRef.current).toFixed(2);
          setChange(ch); setPct(+((ch / openRef.current) * 100).toFixed(2));
          setHigh(h => Math.max(h, xau)); setLow(l => Math.min(l, xau));
          setCandles(c => { const last = c[c.length-1]; return [...c.slice(0,-1), {...last, c:+xau.toFixed(1), h:Math.max(last.h,xau), l:Math.min(last.l,xau)}]; });
          return +xau.toFixed(2);
        });
        return;
      }
    } catch(_) {}
    setPrice(prev => {
      const np = +(prev + (Math.random()-0.501)*2.5).toFixed(2);
      const ch = +(np - openRef.current).toFixed(2);
      setChange(ch); setPct(+((ch/openRef.current)*100).toFixed(2));
      setHigh(h => Math.max(h, np)); setLow(l => Math.min(l, np));
      setCandles(c => { const last=c[c.length-1]; return [...c.slice(0,-1),{...last,c:np,h:Math.max(last.h,np),l:Math.min(last.l,np)}]; });
      return np;
    });
  }, []);

  useEffect(() => {
    fetchPrice();
    const iv = setInterval(fetchPrice, 5000);
    const ci = setInterval(() => setCandles(c => { const l=c[c.length-1]; return [...c.slice(-79),{o:l.c,c:l.c,h:l.c,l:l.c}]; }), 60000);
    return () => { clearInterval(iv); clearInterval(ci); };
  }, [fetchPrice]);

  return { price, change, pct, high, low, candles };
}

// ═══════════════════ HELPERS ═══════════════════
function calcRSI(cls, p=14) {
  if(cls.length<p+1) return 50;
  let g=0,l=0;
  for(let i=cls.length-p;i<cls.length;i++){const d=cls[i]-cls[i-1];if(d>0)g+=d;else l-=d;}
  return +(100-100/(1+g/(l||0.001))).toFixed(1);
}
function calcEMA(arr,p){const k=2/(p+1);let e=arr[0];for(let i=1;i<arr.length;i++)e=arr[i]*k+e*(1-k);return +e.toFixed(1);}

function genSignal(candles, price) {
  const cls=candles.map(c=>c.c);
  const rsi=calcRSI(cls), e9=calcEMA(cls.slice(-9),9), e21=calcEMA(cls.slice(-21),21);
  const last=candles[candles.length-1], prev2=candles[candles.length-2];
  const hammer=last.c>last.o&&(last.c-last.l)>2*(last.c-last.o);
  const shoot=last.c<last.o&&(last.h-last.o)>2*(last.o-last.c);
  const engulf=last.c>last.o&&prev2.c<prev2.o&&last.c>prev2.o;
  const bearEngulf=last.c<last.o&&prev2.c>prev2.o&&last.c<prev2.o;
  let bull=0,bear=0;
  if(rsi<40)bull+=2;if(rsi<30)bull+=2;if(rsi>60)bear+=2;if(rsi>70)bear+=2;
  if(e9>e21)bull+=1;else bear+=1;
  if(hammer||engulf)bull+=2;if(shoot||bearEngulf)bear+=2;
  const isBull=bull>=bear;
  const conf=Math.min(93,Math.max(63,(isBull?bull:bear)*9+46));
  return {
    id:Date.now(), type:isBull?"BUY":"SELL",
    entry:price.toFixed(1),
    tp1:isBull?(price+38).toFixed(1):(price-38).toFixed(1),
    tp2:isBull?(price+76).toFixed(1):(price-76).toFixed(1),
    sl:isBull?(price-19).toFixed(1):(price+19).toFixed(1),
    rr:"1:2.0", conf, rsi, e9, e21,
    time:new Date().toLocaleTimeString("ar",{hour:"2-digit",minute:"2-digit"}),
    reasons:isBull?[
      `RSI عند ${rsi} — ${rsi<35?"تشبع بيع قوي 🟢":"منطقة شراء ✅"}`,
      `EMA9(${e9}) فوق EMA21(${e21}) — إشارة صعود`,
      hammer?"🔨 نمط Hammer صعودي مؤكد على فريم 15 دقيقة":engulf?"✅ Bullish Engulfing مؤكد":"زخم صعودي في الشموع",
      `الهدف ${(price+38).toFixed(1)} ووقف الخسارة ${(price-19).toFixed(1)} — نسبة 1:2`,
    ]:[
      `RSI عند ${rsi} — ${rsi>65?"تشبع شراء قوي 🔴":"منطقة بيع ❌"}`,
      `EMA9(${e9}) تحت EMA21(${e21}) — إشارة هبوط`,
      shoot?"🌟 Shooting Star هبوطي مؤكد على فريم 15 دقيقة":bearEngulf?"❌ Bearish Engulfing مؤكد":"ضغط بيع في الشموع",
      `الهدف ${(price-38).toFixed(1)} ووقف الخسارة ${(price+19).toFixed(1)} — نسبة 1:2`,
    ]
  };
}

// ═══════════════════ CHART ═══════════════════
function CandleChart({candles,tool,drawings,onDraw,showEMA}) {
  const svgRef=useRef(null),[drag,setDrag]=useState(null),[tmp,setTmp]=useState(null);
  const W=340,H=200,PL=50,PR=6,PT=8,PB=22,cW=W-PL-PR,cH=H-PT-PB;
  const vis=candles.slice(-45);
  const allP=vis.flatMap(c=>[c.h,c.l]);
  const minP=Math.min(...allP)-5,maxP=Math.max(...allP)+5,range=maxP-minP||1;
  const cw=Math.max(3.5,(cW/vis.length)*0.6);
  const toY=p=>PT+((maxP-p)/range)*cH,toX=i=>PL+(i+0.5)*(cW/vis.length),toP=y=>maxP-((y-PT)/cH)*range;
  const cls=vis.map(c=>c.c);
  const e9arr=cls.map((_,i)=>cls.slice(Math.max(0,i-8),i+1).reduce((a,b)=>a+b,0)/Math.min(i+1,9));
  const e21arr=cls.map((_,i)=>cls.slice(Math.max(0,i-20),i+1).reduce((a,b)=>a+b,0)/Math.min(i+1,21));
  const gXY=e=>{const rect=svgRef.current.getBoundingClientRect(),cx=e.touches?e.touches[0].clientX:e.clientX,cy=e.touches?e.touches[0].clientY:e.clientY;return{x:(cx-rect.left)*(W/rect.width),y:(cy-rect.top)*(H/rect.height)};};
  const onS=e=>{if(!tool||tool==="cursor")return;e.preventDefault();const p=gXY(e);setDrag(p);setTmp({...p,x2:p.x,y2:p.y});};
  const onM=e=>{if(!drag)return;e.preventDefault();const p=gXY(e);setTmp(t=>({...t,x2:p.x,y2:p.y}));};
  const onE=()=>{if(!drag||!tmp)return;onDraw({type:tool,x1:tmp.x,y1:tmp.y,x2:tmp.x2,y2:tmp.y2,p1:toP(tmp.y),p2:toP(tmp.y2)});setDrag(null);setTmp(null);};
  return(
    <svg ref={svgRef} width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:"block",cursor:tool&&tool!=="cursor"?"crosshair":"default",touchAction:"none"}}
      onMouseDown={onS} onMouseMove={onM} onMouseUp={onE} onTouchStart={onS} onTouchMove={onM} onTouchEnd={onE}>
      <rect x={PL} y={PT} width={cW} height={cH} fill="#0a1628" rx="3"/>
      {[0,1,2,3,4].map(i=>{const y=PT+(i/4)*cH,p=maxP-(i/4)*range;return(<g key={i}><line x1={PL} y1={y} x2={W-PR} y2={y} stroke="rgba(0,255,180,0.05)" strokeWidth="0.8"/><text x={PL-3} y={y+3.5} textAnchor="end" fill="rgba(0,255,180,0.4)" fontSize="7">{p.toFixed(0)}</text></g>);})}
      {showEMA&&<>
        <polyline points={e9arr.map((v,i)=>`${toX(i)},${toY(v)}`).join(" ")} fill="none" stroke="#00d4ff" strokeWidth="1.1" opacity="0.8"/>
        <polyline points={e21arr.map((v,i)=>`${toX(i)},${toY(v)}`).join(" ")} fill="none" stroke="#ff9500" strokeWidth="1.1" opacity="0.8"/>
      </>}
      {vis.map((c,i)=>{const x=toX(i),up=c.c>=c.o,col=up?"#00c97a":"#ff4757",bT=toY(Math.max(c.o,c.c)),bB=toY(Math.min(c.o,c.c));return(<g key={i}><line x1={x} y1={toY(c.h)} x2={x} y2={bT} stroke={col} strokeWidth="0.9"/><line x1={x} y1={bB} x2={x} y2={toY(c.l)} stroke={col} strokeWidth="0.9"/><rect x={x-cw/2} y={bT} width={cw} height={Math.max(1,bB-bT)} fill={col} opacity="0.88" rx="0.3"/></g>);})}
      {drawings.map((d,i)=>{
        if(d.type==="hline")return <g key={i}><line x1={PL} y1={d.y1} x2={W-PR} y2={d.y1} stroke="#f0c040" strokeWidth="1.2" strokeDasharray="6,3"/><text x={W-PR-2} y={d.y1-2} textAnchor="end" fill="#f0c040" fontSize="7">{d.p1.toFixed(1)}</text></g>;
        if(d.type==="trend")return <line key={i} x1={d.x1} y1={d.y1} x2={d.x2} y2={d.y2} stroke="#00d4ff" strokeWidth="1.5"/>;
        if(d.type==="rect"){const rx=Math.min(d.x1,d.x2),ry=Math.min(d.y1,d.y2);return<rect key={i} x={rx} y={ry} width={Math.abs(d.x2-d.x1)} height={Math.abs(d.y2-d.y1)} fill="rgba(0,212,255,0.07)" stroke="#00d4ff" strokeWidth="0.8" strokeDasharray="4,2"/>;}
        if(d.type==="fib"){const fibs=[0,0.236,0.382,0.5,0.618,1],fy1=Math.min(d.y1,d.y2),fy2=Math.max(d.y1,d.y2);return<g key={i}>{fibs.map((f,fi)=>{const fy=fy1+f*(fy2-fy1);return<g key={fi}><line x1={PL} y1={fy} x2={W-PR} y2={fy} stroke="#a78bfa" strokeWidth="0.7" strokeDasharray="3,3"/><text x={W-PR-2} y={fy-2} textAnchor="end" fill="#a78bfa" fontSize="6">{(f*100).toFixed(1)}%</text></g>;})}</g>;}
        return null;
      })}
      {tmp&&tool==="hline"&&<line x1={PL} y1={tmp.y} x2={W-PR} y2={tmp.y} stroke="#f0c040" strokeWidth="1.2" strokeDasharray="5,3" opacity="0.7"/>}
      {tmp&&tool==="trend"&&<line x1={tmp.x} y1={tmp.y} x2={tmp.x2} y2={tmp.y2} stroke="#00d4ff" strokeWidth="1.5" opacity="0.7"/>}
      {tmp&&tool==="rect"&&<rect x={Math.min(tmp.x,tmp.x2)} y={Math.min(tmp.y,tmp.y2)} width={Math.abs(tmp.x2-tmp.x)} height={Math.abs(tmp.y2-tmp.y)} fill="rgba(0,212,255,0.06)" stroke="#00d4ff" strokeWidth="0.8" strokeDasharray="4,2"/>}
      {showEMA&&<><rect x={PL+2} y={PT+2} width={5} height={5} fill="#00d4ff" rx="1"/><text x={PL+10} y={PT+7} fill="#00d4ff" fontSize="6.5">EMA9</text><rect x={PL+38} y={PT+2} width={5} height={5} fill="#ff9500" rx="1"/><text x={PL+46} y={PT+7} fill="#ff9500" fontSize="6.5">EMA21</text></>}
    </svg>
  );
}

function RSIBar({candles}) {
  const cls=candles.slice(-45).map(c=>c.c),rsi=calcRSI(cls);
  const vals=cls.map((_,i)=>i<14?50:calcRSI(cls.slice(0,i+1)));
  const W=340,H=52,PL=50,PR=6,PT=4,PB=12,cW=W-PL-PR,cH=H-PT-PB;
  const toX=i=>PL+(i+0.5)*(cW/cls.length),toY=v=>PT+((100-v)/100)*cH;
  return(
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:"block"}}>
      <rect x={PL} y={PT} width={cW} height={cH} fill="rgba(0,0,0,0.2)" rx="2"/>
      <line x1={PL} y1={toY(70)} x2={W-PR} y2={toY(70)} stroke="rgba(255,71,87,0.4)" strokeWidth="0.8" strokeDasharray="3,2"/>
      <line x1={PL} y1={toY(30)} x2={W-PR} y2={toY(30)} stroke="rgba(0,201,122,0.4)" strokeWidth="0.8" strokeDasharray="3,2"/>
      <text x={PL-3} y={toY(70)+3} textAnchor="end" fill="rgba(255,71,87,0.6)" fontSize="6.5">70</text>
      <text x={PL-3} y={toY(30)+3} textAnchor="end" fill="rgba(0,201,122,0.6)" fontSize="6.5">30</text>
      <polyline points={vals.map((v,i)=>`${toX(i)},${toY(v)}`).join(" ")} fill="none" stroke="#a78bfa" strokeWidth="1.4"/>
      <text x={PL+2} y={PT+8} fill="#a78bfa" fontSize="6.5">RSI {rsi}</text>
    </svg>
  );
}

// ═══════════════════ DATA ═══════════════════
const G="#00c97a";
const Card=({children,style={}})=><div style={{background:"#141e2e",border:"1px solid rgba(255,255,255,0.07)",borderRadius:18,padding:18,...style}}>{children}</div>;
const GCard=({children,style={}})=><div style={{background:"linear-gradient(135deg,#0d2d1f,#0a1e18)",border:"1px solid rgba(0,201,122,0.2)",borderRadius:18,padding:18,...style}}>{children}</div>;
const Pill=({color,children,sm})=><span style={{fontSize:sm?10:11,padding:sm?"2px 8px":"3px 11px",borderRadius:30,background:`${color}15`,color,border:`1px solid ${color}28`,fontWeight:700}}>{children}</span>;

const Circle=({pct,size=72,color="#00c97a",label})=>{
  const r=(size-10)/2,circ=2*Math.PI*r,dash=circ*(pct/100);
  return(
    <div style={{position:"relative",width:size,height:size,flexShrink:0}}>
      <svg width={size} height={size} style={{transform:"rotate(-90deg)"}}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="6"/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="6" strokeDasharray={`${dash} ${circ-dash}`} strokeLinecap="round"/>
      </svg>
      <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
        <span style={{fontSize:15,fontWeight:900,color:"#fff"}}>{pct}%</span>
        {label&&<span style={{fontSize:8,color:"rgba(255,255,255,0.45)"}}>{label}</span>}
      </div>
    </div>
  );
};

const BarChart=({data,color})=>{
  const max=Math.max(...data.map(d=>d.v));
  return(
    <div style={{display:"flex",alignItems:"flex-end",gap:6,height:90,direction:"ltr"}}>
      {data.map((d,i)=>(
        <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
          <span style={{fontSize:9,color:"rgba(255,255,255,0.6)",fontWeight:700}}>{d.v}%</span>
          <div style={{width:"100%",height:`${(d.v/max)*68}px`,background:`linear-gradient(180deg,${color},${color}77)`,borderRadius:"4px 4px 0 0"}}/>
          <span style={{fontSize:8,color:"rgba(255,255,255,0.3)",whiteSpace:"nowrap"}}>{d.m}</span>
        </div>
      ))}
    </div>
  );
};

const PERF=[{m:"ديس",v:67},{m:"يناير",v:73},{m:"فبراير",v:69},{m:"مارس",v:74},{m:"أبريل",v:68},{m:"مايو",v:72}];
const INVEST_P=[{m:"ديس",v:76},{m:"يناير",v:84},{m:"فبراير",v:77},{m:"مارس",v:87},{m:"أبريل",v:78},{m:"مايو",v:83}];
const AI_AGENTS=[
  {name:"سكالب بوت ألفا",desc:"تحليل السكالبينج قصير الأمد",color:"#00c97a",icon:"⚡",acc:84},
  {name:"سوينج بوت برو",desc:"التعرف على أنماط السوينج",color:"#a78bfa",icon:"〰️",acc:79},
  {name:"زون مابر",desc:"رصد مناطق العرض والطلب",color:"#f0c040",icon:"📍",acc:88},
  {name:"تريند واتش AI",desc:"مراقبة الاتجاهات اللحظية",color:"#00d4ff",icon:"📈",acc:81},
  {name:"نيوز ريدر",desc:"تحليل الأخبار الاقتصادية",color:"#ff9500",icon:"📰",acc:76},
];
const CHANNELS=[
  {name:"GOLD SIGNALS PRO",acc:87,type:"BUY",entry:"3,340-3,345",sl:"3,328",tp1:"3,365",tp2:"3,390",time:"منذ 2 ساعة",reason:"كسر مستوى 3,340 مع حجم تداول مرتفع، دعم قوي عند EMA50، RSI خارج من تشبع البيع"},
  {name:"FOREX ADVANCE 🏅",acc:84,type:"SELL",entry:"3,380-3,385",sl:"3,395",tp1:"3,355",tp2:"3,330",time:"منذ 4 ساعات",reason:"مقاومة قوية عند 3,385، نمط Shooting Star على فريم H1، MACD يعطي تقاطع هبوطي"},
  {name:"XAUUSD MASTERS ⭐",acc:81,type:"BUY",entry:"3,315-3,320",sl:"3,305",tp1:"3,345",tp2:"3,370",time:"منذ 6 ساعات",reason:"منطقة دعم و طلب قوية، EMA9 تقطع EMA21 من أسفل، RSI عند 35 خارج تشبع البيع"},
  {name:"SCALP GOLD ⚡",acc:78,type:"SELL",entry:"3,360",sl:"3,372",tp1:"3,340",tp2:"3,320",time:"منذ 8 ساعات",reason:"تشبع شراء على فريم 15 دقيقة، رفض واضح من مستوى 3,360، نمط Bearish Engulfing"},
];
const EDU=[
  {id:1,icon:"📊",title:"أساسيات تداول الذهب",level:"مبتدئ",color:"#00c97a",dur:"15 د",vid:"8JHQH8uBqx4",lessons:[
    {t:"ما هو الذهب؟",c:"الذهب (XAU) معدن ثمين يُتداول مقابل الدولار (XAU/USD).\n\n🔑 لماذا الذهب؟\n• ملاذ آمن في الأزمات والحروب\n• مخزن للقيمة ضد التضخم\n• سيولة عالية 24/5 بلا توقف\n\n📌 أنواع التداول:\n• فوري Spot — تسليم فوري\n• عقود CFDs — فروق الأسعار\n• صناديق ETF — تتبع السعر"},
    {t:"عوامل تحريك السعر",c:"1️⃣ الدولار الأمريكي\nعلاقة عكسية — دولار قوي = ذهب أضعف\n\n2️⃣ أسعار الفائدة\nفائدة أعلى = ضغط على الذهب\n\n3️⃣ التضخم CPI/PCE\nتضخم أعلى = ذهب أقوى\n\n4️⃣ التوترات الجيوسياسية\nأزمات وحروب = طلب أعلى على الذهب\n\n5️⃣ البنوك المركزية\nالصين والهند والروسيا تشتري بكميات ضخمة\n\n6️⃣ بيانات الوظائف NFP\nأول جمعة كل شهر — أهم بيانات للذهب"},
  ]},
  {id:2,icon:"🕯️",title:"الشموع اليابانية",level:"متوسط",color:"#f0c040",dur:"25 د",vid:"5_M6JHQ3pTE",lessons:[
    {t:"مكونات الشمعة",c:"كل شمعة = 4 أسعار:\n• Open الافتتاح\n• Close الإغلاق\n• High الأعلى\n• Low الأدنى\n\n🟢 خضراء: إغلاق > افتتاح (صعود)\n🔴 حمراء: إغلاق < افتتاح (هبوط)\n\nجسم كبير = زخم قوي\nذيل طويل = رفض مستوى"},
    {t:"أنماط الانعكاس الأهم",c:"⬆️ صعودي:\n🔨 Hammer — ذيل سفلي طويل جداً\n⭐ Morning Star — 3 شموع انعكاس صعودي\n✅ Bullish Engulfing — شمعة خضراء تبتلع حمراء\n\n⬇️ هبوطي:\n🌟 Shooting Star — ذيل علوي طويل جداً\n🌆 Evening Star — 3 شموع انعكاس هبوطي\n❌ Bearish Engulfing — شمعة حمراء تبتلع خضراء"},
  ]},
  {id:3,icon:"📉",title:"التحليل الفني المتقدم",level:"متقدم",color:"#ff4757",dur:"40 د",vid:"JmXBBn2GUWE",lessons:[
    {t:"EMA المتحرك الأسي",c:"EMA أسرع وأدق من SMA في التداول\n\n• EMA9 — قصير المدى (يومي)\n• EMA21 — متوسط المدى (أسبوعي)\n• EMA50 — طويل المدى (شهري)\n\n✅ شراء: EMA9 تقطع EMA21 من أسفل\n(Golden Cross)\n\n❌ بيع: EMA9 تقطع EMA21 من أعلى\n(Death Cross)\n\nالسعر فوق EMA50 = اتجاه صعودي رئيسي"},
    {t:"RSI + MACD معاً",c:"RSI (0-100):\n• >70 تشبع شراء ⚠️\n• <30 تشبع بيع ⚠️\n• التباعد = أقوى إشارة\n\nMACD:\n• تقاطع فوق خط الصفر = شراء ✅\n• تقاطع تحت خط الصفر = بيع ❌\n\n🏆 الثلاثة معاً (EMA+RSI+MACD):\nأقوى إشارة في التداول"},
  ]},
  {id:4,icon:"⚖️",title:"إدارة المخاطر",level:"مبتدئ",color:"#a78bfa",dur:"18 د",vid:"oJDqTFWiHCo",lessons:[
    {t:"قاعدة 1-2%",c:"لا تخاطر بأكثر من 1-2% لكل صفقة\n\n💰 مثال ($10,000):\n• 1% = $100 أقصى خسارة لكل صفقة\n• 2% = $200 أقصى خسارة لكل صفقة\n\n📐 حساب الحجم:\nحجم الصفقة = خسارة مسموحة ÷ نقاط SL\n\n⚠️ 90% من المتداولين يخسرون\nلأنهم يتجاهلون هذه القاعدة!"},
    {t:"نسبة R:R وإدارة الصفقة",c:"دائماً استهدف 1:2 أو أفضل\n\n✅ صفقة جيدة (1:2):\nخسارة $100 → ربح $200\n\n❌ صفقة سيئة (1:1):\nخسارة $100 → ربح $100\n\n🎯 إدارة الصفقة:\n• احرك SL لنقطة التعادل بعد الهدف 1\n• أغلق 50% عند الهدف 1\n• اترك 50% تسير للهدف 2"},
  ]},
];

const SYS=(p)=>`أنت "AN Gold AI" — مستشار تداول احترافي متخصص في الذهب.

السعر الحالي: $${p} XAU/USD (مايو 2026)
البيانات: آخر تحديث منذ ثوانٍ

تخصصاتك الكاملة:
- التحليل الفني: EMA9/EMA21/EMA50, RSI, MACD, شموع يابانية
- التحليل الأساسي: الفيدرالي, الدولار, التضخم, NFP
- إشارات التداول مع نقاط دخول/خروج/SL/TP واضحة
- تحليل صور الشارت المرفوعة
- إدارة المخاطر ونسبة R:R

قواعد مهمة:
✅ استخدم السعر الحالي $${p} دائماً
✅ كل إشارة تشمل: نوع / دخول / SL / TP1 / TP2 / R:R / السبب
✅ اذكر الفريم الزمني (15 دقيقة / 30 دقيقة / ساعة)
✅ الرد بالعربية فقط بأسلوب محترف
✅ إذا رُفعت صورة شارت، حللها وأعطِ أفضل صفقة`;

const NAV=[
  {id:"home",icon:"🏠",label:"الرئيسية"},
  {id:"advisor",icon:"🧠",label:"المستشار"},
  {id:"signals",icon:"📡",label:"الإشارات"},
  {id:"perf",icon:"📊",label:"الأداء"},
  {id:"invest",icon:"🏦",label:"الاستثمار"},
  {id:"profile",icon:"👤",label:"ملفي"},
];

// ═══════════════════ HOME ═══════════════════
function HomePage({gold,setPage}) {
  const {price,change,pct,high,low,candles}=gold;
  const up=change>=0;
  const cls=candles.map(c=>c.c),rsi=calcRSI(cls),e21=calcEMA(cls.slice(-21),21);
  const tools=[
    {title:"تحليل الشارت",desc:"احصل على أفضل صفقة باستخدام 8 وكلاء ذكاء اصطناعي",icon:"📊",color:"#00c97a",bg:"#0d2d1f",page:"advisor"},
    {title:"التحقق من توصية",desc:"تأكد من التوصية قبل دخولك — هل هي صحيحة أم لا",icon:"🔍",color:"#00d4ff",bg:"#0a1e2d",page:"signals"},
    {title:"مناطق العرض والطلب",desc:"حدد جميع مناطق البيع والشراء لليوم كاملاً",icon:"📍",color:"#a78bfa",bg:"#1a1240",page:"perf"},
  ];
  return(
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <GCard>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
          <span style={{width:8,height:8,borderRadius:"50%",background:"#00c97a",boxShadow:"0 0 8px #00c97a",display:"inline-block"}}/>
          <span style={{color:"rgba(0,201,122,0.8)",fontSize:11}}>12 وكيل ذكاء اصطناعي يعملون لديك</span>
        </div>
        <div style={{color:"rgba(255,255,255,0.5)",fontSize:12,marginBottom:3,direction:"rtl"}}>👋 مرحباً بك</div>
        <div style={{color:"#fff",fontSize:20,fontWeight:800,direction:"rtl",marginBottom:14}}>ماذا تريد <span style={{color:"#00c97a"}}>اليوم؟</span></div>
        <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,direction:"rtl",marginBottom:10}}>أدوات التحليل</div>
        {tools.map(t=>(
          <div key={t.title} onClick={()=>setPage(t.page)} style={{background:t.bg,border:`1px solid ${t.color}22`,borderRadius:14,padding:"13px 15px",marginBottom:10,cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{color:"rgba(255,255,255,0.3)",fontSize:16}}>‹</span>
            <div style={{flex:1,direction:"rtl",marginRight:10}}>
              <div style={{color:t.color,fontWeight:700,fontSize:14}}>{t.title}</div>
              <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>{t.desc}</div>
            </div>
            <div style={{width:44,height:44,borderRadius:12,background:`${t.color}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>{t.icon}</div>
          </div>
        ))}
      </GCard>
      <GCard>
        <div style={{color:"rgba(0,201,122,0.6)",fontSize:11,direction:"rtl",marginBottom:6}}>سعر الذهب الفوري • XAU/USD</div>
        <div style={{display:"flex",alignItems:"baseline",gap:10,flexWrap:"wrap"}}>
          <span style={{fontSize:42,fontWeight:900,color:up?"#00c97a":"#ff4757",letterSpacing:-1,transition:"color 0.4s"}}>${price.toLocaleString()}</span>
          <span style={{fontSize:13,fontWeight:700,padding:"3px 10px",borderRadius:20,background:up?"rgba(0,201,122,0.15)":"rgba(255,71,87,0.15)",color:up?"#00c97a":"#ff4757"}}>{up?"▲":"▼"} {up?"+":""}{change.toFixed(2)} ({pct.toFixed(2)}%)</span>
        </div>
        <div style={{color:"rgba(255,255,255,0.28)",fontSize:10,marginTop:4,direction:"rtl"}}>تحديث كل 5 ثوانٍ تلقائياً</div>
        <div style={{display:"flex",gap:14,marginTop:12,direction:"rtl",flexWrap:"wrap"}}>
          {[{l:"أعلى اليوم",v:`$${high.toFixed(1)}`,c:"#00c97a"},{l:"أدنى اليوم",v:`$${low.toFixed(1)}`,c:"#ff4757"},{l:"RSI",v:rsi,c:rsi<35?"#00c97a":rsi>65?"#ff4757":"#f0c040"},{l:"الاتجاه",v:price>e21?"صعودي":"هبوطي",c:price>e21?"#00c97a":"#ff4757"}].map(x=>(
            <div key={x.l}><div style={{fontSize:9,color:"rgba(255,255,255,0.35)"}}>{x.l}</div><div style={{color:x.c,fontWeight:700,fontSize:12}}>{x.v}</div></div>
          ))}
        </div>
      </GCard>
    </div>
  );
}

// ═══════════════════ ADVISOR ═══════════════════
function AdvisorPage({price}) {
  const [msgs,setMsgs]=useState([{role:"assistant",content:`مرحباً! أنا مستشارك الذكي 🤖\n\nسعر الذهب الآن: $${price}\n\nيمكنني مساعدتك في:\n• تحليل الشارت الذي ترفعه 📊\n• التحقق من أي توصية 🔍\n• أفضل صفقة الآن مع SL وTP 🎯\n• شرح أي مفهوم في التداول 📚\n\nأرفع صورة الشارت أو اسألني مباشرة!`}]);
  const [input,setInput]=useState(""),[loading,setLoading]=useState(false),[history,setHistory]=useState([]);
  const [imgB64,setImgB64]=useState(null),[imgPrev,setImgPrev]=useState(null);
  const bottomRef=useRef(null),fileRef=useRef(null);
  const EXAMPLES=["دخلت شراء ذهب من 3340 والسعر نزل 3320، أنتظر أم أخرج بخسارة؟","فاتح بيع ذهب من 3380 والسعر صار 3365، أثبت أم أطلع؟","أعطني أفضل صفقة الآن على الذهب مع SL وTP","ما مستويات الدعم والمقاومة الأهم الآن؟"];
  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[msgs,loading]);
  const handleImg=e=>{const f=e.target.files[0];if(!f)return;const reader=new FileReader();reader.onload=ev=>{setImgB64(ev.target.result.split(",")[1]);setImgPrev(ev.target.result);};reader.readAsDataURL(f);};
  const send=async(text)=>{
    const t=(text||input).trim();
    if(!t&&!imgB64||loading)return;
    setInput("");
    const userContent=[];
    if(imgB64)userContent.push({type:"image",source:{type:"base64",media_type:"image/jpeg",data:imgB64}});
    userContent.push({type:"text",text:t||(imgB64?"حلل هذا الشارت وأعطني أفضل صفقة مع SL وTP واذكر الفريم الزمني":"")});
    setMsgs(p=>[...p,{role:"user",content:t||(imgB64?"📊 [صورة الشارت للتحليل]":""),img:imgPrev}]);
    setImgB64(null);setImgPrev(null);
    setLoading(true);
    const newH=[...history,{role:"user",content:userContent.length===1?userContent[0].text:userContent}];
    try{
      const res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,system:SYS(price),messages:newH})});
      if(!res.ok)throw new Error(`HTTP ${res.status}`);
      const data=await res.json();
      if(data.error)throw new Error(data.error.message);
      const reply=(data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n").trim()||"لم أتمكن من الرد.";
      setMsgs(p=>[...p,{role:"assistant",content:reply}]);
      setHistory([...newH,{role:"assistant",content:reply}]);
    }catch(err){setMsgs(p=>[...p,{role:"assistant",content:`⚠️ خطأ: ${err.message}`}]);}
    setLoading(false);
  };
  return(
    <div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 165px)",minHeight:460}}>
      <GCard style={{padding:"12px 16px",borderRadius:"16px 16px 0 0"}}>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div><div style={{color:"#00c97a",fontWeight:800,fontSize:15}}>🧠 المستشار الذكي</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginTop:2}}>ارفع شارتك أو اسأل مباشرة</div></div>
          <div style={{display:"flex",alignItems:"center",gap:5}}>
            <span style={{width:7,height:7,borderRadius:"50%",background:loading?"#f0c040":"#00c97a",display:"inline-block"}}/>
            <span style={{color:loading?"#f0c040":"#00c97a",fontSize:11}}>{loading?"يفكر...":"متصل"}</span>
          </div>
        </div>
      </GCard>
      <div style={{display:"flex",gap:8,padding:"8px 12px",background:"rgba(0,0,0,0.3)",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
        <input ref={fileRef} type="file" accept="image/*" onChange={handleImg} style={{display:"none"}}/>
        <button onClick={()=>fileRef.current?.click()} style={{flex:1,background:"rgba(0,201,122,0.1)",border:"1px dashed rgba(0,201,122,0.3)",borderRadius:12,padding:"8px",color:"#00c97a",cursor:"pointer",fontFamily:"inherit",fontSize:12,direction:"rtl"}}>📊 ارفع صورة الشارت للتحليل</button>
        {imgPrev&&<div style={{width:44,height:44,borderRadius:8,overflow:"hidden",flexShrink:0}}><img src={imgPrev} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/></div>}
      </div>
      <div style={{display:"flex",gap:6,padding:"6px 10px",overflowX:"auto",scrollbarWidth:"none",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
        {EXAMPLES.map(e=><button key={e} onClick={()=>send(e)} disabled={loading} style={{flexShrink:0,background:"rgba(0,201,122,0.07)",border:"1px solid rgba(0,201,122,0.18)",borderRadius:20,color:"rgba(0,201,122,0.85)",fontSize:10,padding:"4px 10px",cursor:"pointer",fontFamily:"inherit",whiteSpace:"nowrap",maxWidth:180,overflow:"hidden",textOverflow:"ellipsis"}}>{e}</button>)}
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"12px",background:"rgba(6,12,20,0.6)",display:"flex",flexDirection:"column",gap:10}}>
        {msgs.map((m,i)=>(
          <div key={i} style={{display:"flex",justifyContent:m.role==="assistant"?"flex-start":"flex-end"}}>
            {m.role==="assistant"&&<div style={{width:30,height:30,borderRadius:"50%",background:"linear-gradient(135deg,#00c97a,#009955)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,marginRight:7,flexShrink:0,alignSelf:"flex-end"}}>🤖</div>}
            <div style={{maxWidth:"78%",display:"flex",flexDirection:"column",gap:4}}>
              {m.img&&<img src={m.img} alt="" style={{maxWidth:"100%",borderRadius:10}}/>}
              <div style={{padding:"9px 13px",borderRadius:m.role==="assistant"?"14px 14px 14px 3px":"14px 14px 3px 14px",background:m.role==="assistant"?"rgba(0,201,122,0.08)":"linear-gradient(135deg,#00c97a,#009955)",color:m.role==="assistant"?"rgba(255,255,255,0.88)":"#000",border:m.role==="assistant"?"1px solid rgba(0,201,122,0.15)":"none",fontSize:13,lineHeight:1.65,whiteSpace:"pre-wrap",direction:"rtl",textAlign:"right"}}>{m.content}</div>
            </div>
          </div>
        ))}
        {loading&&(
          <div style={{display:"flex",gap:7,alignItems:"center"}}>
            <div style={{width:30,height:30,borderRadius:"50%",background:"linear-gradient(135deg,#00c97a,#009955)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>🤖</div>
            <div style={{display:"flex",gap:4,padding:"9px 14px",background:"rgba(0,201,122,0.08)",borderRadius:14,border:"1px solid rgba(0,201,122,0.15)"}}>
              {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:"50%",background:"#00c97a",animation:"bounce 1.2s infinite",animationDelay:`${i*0.2}s`}}/>)}
            </div>
          </div>
        )}
        <div ref={bottomRef}/>
      </div>
      <div style={{display:"flex",gap:8,padding:"10px 12px",background:"rgba(6,12,20,0.97)",borderTop:"1px solid rgba(0,201,122,0.1)"}}>
        <button onClick={()=>send()} disabled={(!input.trim()&&!imgB64)||loading} style={{width:40,height:40,borderRadius:"50%",flexShrink:0,background:(input.trim()||imgB64)&&!loading?"linear-gradient(135deg,#00c97a,#009955)":"rgba(0,201,122,0.08)",border:"none",cursor:(input.trim()||imgB64)&&!loading?"pointer":"not-allowed",fontSize:18}}>📤</button>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")send();}} placeholder="اشرح موقفك أو اسأل عن الذهب..." style={{flex:1,background:"rgba(0,201,122,0.06)",border:"1px solid rgba(0,201,122,0.18)",borderRadius:20,padding:"9px 14px",color:"#fff",fontSize:13,fontFamily:"inherit",direction:"rtl",outline:"none"}}/>
      </div>
    </div>
  );
}

// ═══════════════════ SIGNALS ═══════════════════
function SignalsPage({candles,price}) {
  const [signals,setSignals]=useState([]),[open,setOpen]=useState(null),[cd,setCd]=useState(3600),[tab,setTab]=useState("channels"),[frame,setFrame]=useState("15m");
  const gen=useCallback(()=>{setSignals([genSignal(candles,price),genSignal(candles.slice(0,-8),price+(Math.random()*6-3))]);setCd(3600);},[candles,price]);
  useEffect(()=>{gen();},[]);
  useEffect(()=>{const t=setInterval(()=>setCd(c=>{if(c<=1){gen();return 3600;}return c-1;}),1000);return()=>clearInterval(t);},[gen]);
  const m=Math.floor(cd/60),s=cd%60;
  const cls=candles.map(c=>c.c),rsi=calcRSI(cls),e9=calcEMA(cls.slice(-9),9),e21=calcEMA(cls.slice(-21),21);
  const FRAMES=["15m","30m","1h"];
  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <GCard style={{padding:"14px 18px"}}>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div><div style={{color:"#00c97a",fontWeight:800,fontSize:15}}>📡 الإشارات</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:3}}>AI: {m}:{s.toString().padStart(2,"0")}</div></div>
          <button onClick={gen} style={{background:"rgba(0,201,122,0.15)",border:"1px solid rgba(0,201,122,0.3)",color:"#00c97a",padding:"7px 16px",borderRadius:20,cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:700}}>🔄 تحديث</button>
        </div>
        <div style={{display:"flex",gap:8,marginTop:10,direction:"rtl"}}>
          {[{l:"RSI",v:rsi,c:rsi<35?"#00c97a":rsi>65?"#ff4757":"#f0c040"},{l:"EMA9",v:e9.toFixed(0),c:"#00d4ff"},{l:"EMA21",v:e21.toFixed(0),c:"#ff9500"},{l:"$",v:price,c:"#fff"}].map(x=>(
            <div key={x.l} style={{background:"rgba(255,255,255,0.05)",borderRadius:10,padding:"5px 10px",textAlign:"center"}}>
              <div style={{fontSize:9,color:"rgba(255,255,255,0.4)"}}>{x.l}</div>
              <div style={{color:x.c,fontWeight:700,fontSize:12}}>{x.v}</div>
            </div>
          ))}
        </div>
      </GCard>
      <div style={{display:"flex",gap:8}}>
        {[{id:"channels",l:"📡 قنوات موثوقة"},{id:"ai",l:"🤖 AI إشارات"}].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"9px",borderRadius:12,border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:700,background:tab===t.id?"#00c97a":"rgba(255,255,255,0.06)",color:tab===t.id?"#000":"rgba(255,255,255,0.5)"}}>{t.l}</button>
        ))}
      </div>
      {tab==="ai"&&(
        <div style={{display:"flex",gap:6,direction:"rtl"}}>
          <span style={{color:"rgba(255,255,255,0.5)",fontSize:12,lineHeight:"32px"}}>الفريم:</span>
          {FRAMES.map(f=><button key={f} onClick={()=>setFrame(f)} style={{padding:"5px 12px",borderRadius:10,border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:700,background:frame===f?"#00c97a":"rgba(255,255,255,0.07)",color:frame===f?"#000":"rgba(255,255,255,0.5)"}}>{f}</button>)}
        </div>
      )}
      {tab==="ai"&&signals.map((sig,i)=>(
        <Card key={sig.id} style={{cursor:"pointer",borderColor:open===i?"rgba(0,201,122,0.3)":"rgba(255,255,255,0.07)"}} onClick={()=>setOpen(open===i?null:i)}>
          <div style={{direction:"rtl"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
              <div style={{display:"flex",gap:7,alignItems:"center"}}>
                <span style={{fontSize:13,fontWeight:800,padding:"4px 14px",borderRadius:20,background:sig.type==="BUY"?"rgba(0,201,122,0.18)":"rgba(255,71,87,0.18)",color:sig.type==="BUY"?"#00c97a":"#ff4757",border:`1px solid ${sig.type==="BUY"?"rgba(0,201,122,0.35)":"rgba(255,71,87,0.35)"}`}}>{sig.type==="BUY"?"🟢 شراء":"🔴 بيع"}</span>
                <Pill color="#f0c040" sm>{frame}</Pill>
                <span style={{color:"rgba(255,255,255,0.35)",fontSize:10}}>{sig.time}</span>
              </div>
              <span style={{color:"#fff",fontWeight:700}}>XAU/USD</span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
              {[{l:"📍 الدخول",v:`$${sig.entry}`,c:"#fff"},{l:"🛑 وقف الخسارة",v:`$${sig.sl}`,c:"#ff4757"},{l:"🎯 الهدف 1",v:`$${sig.tp1}`,c:"#00c97a"},{l:"🎯 الهدف 2",v:`$${sig.tp2}`,c:"#00c97a"}].map(item=>(
                <div key={item.l} style={{background:"rgba(255,255,255,0.04)",borderRadius:12,padding:"10px 12px"}}>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.38)",marginBottom:3}}>{item.l}</div>
                  <div style={{fontSize:16,fontWeight:700,color:item.c}}>{item.v}</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex",justifyContent:"space-between",marginTop:10,alignItems:"center"}}>
              <span style={{fontSize:11,color:"rgba(255,255,255,0.35)"}}>R:R <span style={{color:"#f0c040",fontWeight:700}}>{sig.rr}</span></span>
              <div style={{display:"flex",gap:7,alignItems:"center"}}>
                <div style={{width:70,height:5,background:"rgba(255,255,255,0.1)",borderRadius:3,overflow:"hidden"}}><div style={{width:`${sig.conf}%`,height:"100%",background:sig.conf>80?"#00c97a":"#f0c040",borderRadius:3}}/></div>
                <span style={{fontSize:12,fontWeight:700,color:sig.conf>80?"#00c97a":"#f0c040"}}>{sig.conf}%</span>
              </div>
            </div>
            {open===i&&(
              <div style={{marginTop:12,padding:"12px",background:"rgba(0,201,122,0.06)",borderRadius:12,border:"1px solid rgba(0,201,122,0.12)"}}>
                <div style={{color:"#00c97a",fontWeight:700,fontSize:12,marginBottom:8}}>💡 أسباب الإشارة — فريم {frame}:</div>
                {sig.reasons.map((r,ri)=><div key={ri} style={{color:"rgba(255,255,255,0.7)",fontSize:12,marginBottom:5}}>• {r}</div>)}
              </div>
            )}
            <div style={{textAlign:"center",marginTop:6,fontSize:10,color:"rgba(255,255,255,0.25)"}}>{open===i?"▲ إخفاء":"▼ عرض الأسباب"}</div>
          </div>
        </Card>
      ))}
      {tab==="channels"&&CHANNELS.map((ch,i)=>(
        <Card key={i} style={{cursor:"pointer",borderColor:open===i?"rgba(0,201,122,0.3)":"rgba(255,255,255,0.07)"}} onClick={()=>setOpen(open===i?null:i)}>
          <div style={{direction:"rtl"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <div style={{display:"flex",gap:6,alignItems:"center"}}>
                <span style={{fontSize:13,fontWeight:800,padding:"4px 14px",borderRadius:20,background:ch.type==="BUY"?"rgba(0,201,122,0.18)":"rgba(255,71,87,0.18)",color:ch.type==="BUY"?"#00c97a":"#ff4757",border:`1px solid ${ch.type==="BUY"?"rgba(0,201,122,0.35)":"rgba(255,71,87,0.35)"}`}}>{ch.type==="BUY"?"🟢 شراء":"🔴 بيع"}</span>
                <span style={{color:"rgba(255,255,255,0.35)",fontSize:10}}>{ch.time}</span>
              </div>
              <div style={{textAlign:"right"}}><div style={{color:"#00d4ff",fontWeight:700,fontSize:12}}>{ch.name}</div><Pill color="#f0c040" sm>دقة {ch.acc}%</Pill></div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
              {[{l:"📍 الدخول",v:ch.entry,c:"#fff"},{l:"🛑 وقف الخسارة",v:ch.sl,c:"#ff4757"},{l:"🎯 الهدف 1",v:ch.tp1,c:"#00c97a"},{l:"🎯 الهدف 2",v:ch.tp2,c:"#00c97a"}].map(item=>(
                <div key={item.l} style={{background:"rgba(255,255,255,0.04)",borderRadius:12,padding:"10px 12px"}}>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.38)",marginBottom:3}}>{item.l}</div>
                  <div style={{fontSize:15,fontWeight:700,color:item.c}}>{item.v}</div>
                </div>
              ))}
            </div>
            {open===i&&(
              <div style={{marginTop:12,padding:"12px",background:"rgba(0,201,122,0.06)",borderRadius:12,border:"1px solid rgba(0,201,122,0.12)"}}>
                <div style={{color:"#00c97a",fontWeight:700,fontSize:12,marginBottom:8}}>💡 سبب الإشارة:</div>
                <div style={{color:"rgba(255,255,255,0.7)",fontSize:12,lineHeight:1.7}}>{ch.reason}</div>
              </div>
            )}
            <div style={{textAlign:"center",marginTop:8,fontSize:10,color:"rgba(255,255,255,0.25)"}}>{open===i?"▲ إخفاء":"▼ عرض السبب"}</div>
          </div>
        </Card>
      ))}
      <div style={{padding:"10px 14px",background:"rgba(255,71,87,0.07)",borderRadius:12,border:"1px solid rgba(255,71,87,0.15)",direction:"rtl"}}>
        <div style={{color:"rgba(255,255,255,0.5)",fontSize:11,lineHeight:1.6}}>⚠️ للأغراض التعليمية فقط. التداول ينطوي على مخاطر.</div>
      </div>
    </div>
  );
}

// ═══════════════════ PERF ═══════════════════
function PerfPage() {
  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{color:"#fff",fontWeight:800,fontSize:18,direction:"rtl"}}>📊 مراقبة الأداء</div>
        <span style={{background:"rgba(0,201,122,0.15)",border:"1px solid rgba(0,201,122,0.3)",color:"#00c97a",padding:"4px 12px",borderRadius:20,fontSize:11,fontWeight:700}}>● مباشر</span>
      </div>
      <GCard>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{color:"rgba(255,255,255,0.5)",fontSize:11,direction:"rtl",marginBottom:4}}>دقة التحليل اليوم</div>
            <div style={{color:"#00c97a",fontSize:46,fontWeight:900}}>78%</div>
            <div style={{color:"rgba(0,201,122,0.7)",fontSize:12,direction:"rtl"}}>📈 أداء هذا الشهر</div>
          </div>
          <Circle pct={79} size={80} color="#00c97a" label="نجاح"/>
        </div>
      </GCard>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:12}}>
        {[{icon:"👥",v:"124,051",l:"مستخدمون نشطون",c:"#00c97a",bg:"#0d2d1f"},{icon:"🎯",v:"78%",l:"دقة التحليل",c:"#00c97a",bg:"#0d2d1f"},{icon:"✅",v:"+300",l:"قنوات موثوقة",c:"#f0c040",bg:"#1e1a0d"},{icon:"🤖",v:"12",l:"وكلاء AI",c:"#a78bfa",bg:"#140d2d"}].map(s=>(
          <div key={s.l} style={{background:s.bg,border:`1px solid ${s.c}20`,borderRadius:16,padding:"14px"}}>
            <div style={{fontSize:24,marginBottom:6}}>{s.icon}</div>
            <div style={{fontSize:24,fontWeight:800,color:s.c}}>{s.v}</div>
            <div style={{fontSize:11,color:"rgba(255,255,255,0.45)",marginTop:3,direction:"rtl"}}>{s.l}</div>
          </div>
        ))}
      </div>
      <Card>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <div style={{color:"rgba(255,255,255,0.4)",fontSize:11}}>📅 آخر 6 أشهر</div>
          <div style={{color:"#fff",fontWeight:700}}>الأداء — آخر 6 أشهر</div>
        </div>
        <BarChart data={PERF} color="#f0c040"/>
      </Card>
      <Card>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <span style={{color:"#00c97a",fontSize:12,fontWeight:700}}>عرض الكل ›</span>
          <span style={{color:"#fff",fontWeight:700,fontSize:14}}>🤖 وكلاء AI النشطون</span>
        </div>
        {AI_AGENTS.map(a=>(
          <div key={a.name} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10,padding:"10px 12px",background:"rgba(255,255,255,0.03)",borderRadius:12,direction:"rtl"}}>
            <div style={{display:"flex",gap:10,alignItems:"center"}}>
              <div style={{width:40,height:40,borderRadius:10,background:`${a.color}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{a.icon}</div>
              <div><div style={{color:"#fff",fontWeight:700,fontSize:13}}>{a.name}</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginTop:2}}>{a.desc}</div></div>
            </div>
            <div style={{fontWeight:800,fontSize:18,color:a.color}}>{a.acc}%</div>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ═══════════════════ INVEST ═══════════════════
function InvestPage() {
  const [tab,setTab]=useState("overview");
  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{color:"#fff",fontWeight:800,fontSize:18,direction:"rtl"}}>🏦 إدارة الاستثمار</div>
        <span style={{background:"rgba(0,201,122,0.15)",border:"1px solid rgba(0,201,122,0.3)",color:"#00c97a",padding:"4px 12px",borderRadius:20,fontSize:11}}>● مباشر</span>
      </div>
      <div style={{display:"flex",gap:8}}>
        {[{id:"overview",l:"نظرة عامة"},{id:"team",l:"الفريق"},{id:"top",l:"أفضل المتداولين"}].map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"8px",borderRadius:12,border:"none",cursor:"pointer",fontFamily:"inherit",fontSize:11,fontWeight:700,background:tab===t.id?"#00c97a":"rgba(255,255,255,0.06)",color:tab===t.id?"#000":"rgba(255,255,255,0.5)"}}>{t.l}</button>
        ))}
      </div>
      {tab==="overview"&&<>
        <div style={{background:"linear-gradient(135deg,#0a1e14,#0d3020)",border:"1px solid rgba(0,201,122,0.25)",borderRadius:20,padding:"20px"}}>
          <div style={{color:"rgba(255,255,255,0.5)",fontSize:12,direction:"rtl",marginBottom:4}}>📦 إجمالي الاستثمارات المُدارة</div>
          <div style={{color:"#00c97a",fontSize:48,fontWeight:900}}>$124K+</div>
          <div style={{background:"rgba(240,192,64,0.12)",border:"1px solid rgba(240,192,64,0.25)",borderRadius:12,padding:"8px 14px",direction:"rtl",margin:"12px 0"}}>
            <span style={{color:"#f0c040",fontSize:12}}>⏰ الأماكن ممتلئة — قائمة انتظار متاحة</span>
          </div>
          <button style={{width:"100%",background:"#00c97a",border:"none",borderRadius:14,padding:"13px",color:"#000",fontFamily:"inherit",fontSize:15,fontWeight:800,cursor:"pointer"}}>📋 سجّل في قائمة الانتظار ›</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:12}}>
          {[{icon:"🏦",v:"$124K",l:"إجمالي الاستثمارات",c:"#00c97a",bg:"#0d2d1f"},{icon:"📈",v:"66%",l:"متوسط العائد",c:"#00c97a",bg:"#0d2d1f"},{icon:"✅",v:"79%",l:"نسبة النجاح",c:"#f0c040",bg:"#1e1a0d"},{icon:"👥",v:"300/300",l:"المشتركون",c:"#ff4757",bg:"#2d0d0d"}].map(s=>(
            <div key={s.l} style={{background:s.bg,border:`1px solid ${s.c}20`,borderRadius:16,padding:"14px"}}>
              <div style={{width:40,height:40,borderRadius:10,background:`${s.c}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,marginBottom:8}}>{s.icon}</div>
              <div style={{fontSize:22,fontWeight:800,color:s.c}}>{s.v}</div>
              <div style={{fontSize:11,color:"rgba(255,255,255,0.45)",marginTop:3,direction:"rtl"}}>{s.l}</div>
            </div>
          ))}
        </div>
        <Card>
          <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
            <span style={{color:"rgba(255,255,255,0.4)",fontSize:11}}>📅 آخر 6 أشهر</span>
            <span style={{color:"#fff",fontWeight:700}}>الأداء الشهري</span>
          </div>
          <BarChart data={INVEST_P} color="#00c97a"/>
        </Card>
      </>}
      {tab==="team"&&(
        <Card>
          <div style={{color:"#fff",fontWeight:700,fontSize:14,direction:"rtl",marginBottom:14}}>👨‍💼 الفريق المتخصص</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10,marginBottom:12}}>
            <div style={{background:"#0d2d1f",border:"1px solid rgba(0,201,122,0.2)",borderRadius:14,padding:"14px",textAlign:"center"}}>
              <div style={{color:"#00c97a",fontSize:32,fontWeight:900}}>5</div>
              <div style={{color:"rgba(255,255,255,0.7)",fontSize:13,fontWeight:700,marginTop:4,direction:"rtl"}}>👨‍💻 محللون متخصصون</div>
              <div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginTop:3,direction:"rtl"}}>تحليل يومي متخصص</div>
            </div>
            <div style={{background:"#1a1240",border:"1px solid rgba(167,139,250,0.2)",borderRadius:14,padding:"14px",textAlign:"center"}}>
              <div style={{color:"#a78bfa",fontSize:32,fontWeight:900}}>9</div>
              <div style={{color:"rgba(255,255,255,0.7)",fontSize:13,fontWeight:700,marginTop:4,direction:"rtl"}}>🤖 وكيل AI</div>
              <div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginTop:3,direction:"rtl"}}>إدارة المحافظ والأموال</div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:6,direction:"rtl",background:"rgba(0,201,122,0.06)",borderRadius:10,padding:"10px"}}>
            <span style={{fontSize:16}}>🛡️</span>
            <span style={{color:"rgba(255,255,255,0.5)",fontSize:11}}>يعمل الفريق على مدار الساعة لضمان أفضل النتائج</span>
          </div>
        </Card>
      )}
      {tab==="top"&&(
        <Card>
          <div style={{color:"#fff",fontWeight:700,fontSize:14,direction:"rtl",marginBottom:14}}>🏆 أفضل 10 متداولين</div>
          {[{n:"أحمد م.",p:"+$12,400",acc:"91%",rank:1,flag:"🥇"},{n:"محمد س.",p:"+$9,800",acc:"88%",rank:2,flag:"🥈"},{n:"خالد ع.",p:"+$8,200",acc:"85%",rank:3,flag:"🥉"},{n:"سعد ل.",p:"+$7,100",acc:"83%",rank:4,flag:"4️⃣"},{n:"فهد م.",p:"+$6,500",acc:"81%",rank:5,flag:"5️⃣"}].map(t=>(
            <div key={t.rank} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10,padding:"10px 12px",background:"rgba(255,255,255,0.03)",borderRadius:12,direction:"rtl"}}>
              <Pill color="#f0c040" sm>{t.acc}</Pill>
              <div style={{textAlign:"right"}}><div style={{color:"#fff",fontWeight:700}}>{t.n}</div><div style={{color:"#00c97a",fontSize:11}}>{t.p}</div></div>
              <div style={{fontSize:24}}>{t.flag}</div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

// ═══════════════════ CHART PAGE ═══════════════════
function ChartPage({gold}) {
  const {candles,price}=gold;
  const [tool,setTool]=useState("cursor"),[drawings,setDrawings]=useState([]),[showEMA,setShowEMA]=useState(true),[showRSI,setShowRSI]=useState(true);
  const cls=candles.map(c=>c.c),rsi=calcRSI(cls),e9=calcEMA(cls.slice(-9),9),e21=calcEMA(cls.slice(-21),21);
  const TOOLS=[{id:"cursor",icon:"↖",l:"مؤشر"},{id:"hline",icon:"—",l:"أفقي"},{id:"trend",icon:"↗",l:"اتجاه"},{id:"rect",icon:"▭",l:"مستطيل"},{id:"fib",icon:"φ",l:"فيبو"}];
  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <Card style={{padding:"10px 12px"}}>
        <div style={{display:"flex",gap:4,marginBottom:8,justifyContent:"space-between"}}>
          <div style={{display:"flex",gap:4}}>{TOOLS.map(t=><button key={t.id} onClick={()=>setTool(t.id)} title={t.l} style={{padding:"5px 9px",borderRadius:8,fontSize:12,border:"none",cursor:"pointer",fontFamily:"inherit",background:tool===t.id?"#00c97a":"rgba(255,255,255,0.06)",color:tool===t.id?"#000":"rgba(255,255,255,0.6)",fontWeight:700}}>{t.icon}</button>)}</div>
          <button onClick={()=>setDrawings([])} style={{padding:"5px 10px",borderRadius:8,fontSize:11,border:"none",cursor:"pointer",fontFamily:"inherit",background:"rgba(255,71,87,0.15)",color:"#ff4757",fontWeight:700}}>✕ مسح</button>
        </div>
        <div style={{display:"flex",gap:7}}>
          {[{l:"EMA",v:showEMA,s:setShowEMA,c:"#00d4ff"},{l:"RSI",v:showRSI,s:setShowRSI,c:"#a78bfa"}].map(i=>(
            <button key={i.l} onClick={()=>i.s(!i.v)} style={{padding:"4px 11px",borderRadius:12,fontSize:11,border:"none",cursor:"pointer",fontFamily:"inherit",background:i.v?`${i.c}18`:"rgba(255,255,255,0.04)",color:i.v?i.c:"rgba(255,255,255,0.3)",fontWeight:i.v?700:400}}>{i.l}</button>
          ))}
        </div>
      </Card>
      <Card style={{padding:"10px 8px"}}>
        <CandleChart candles={candles} tool={tool} drawings={drawings} onDraw={d=>setDrawings(p=>[...p,d])} showEMA={showEMA}/>
        {showRSI&&<div style={{marginTop:3}}><RSIBar candles={candles}/></div>}
      </Card>
      <Card>
        <div style={{color:"#00c97a",fontWeight:700,fontSize:13,direction:"rtl",marginBottom:10}}>📊 المؤشرات اللحظية</div>
        {[{n:"RSI (14)",v:rsi,s:rsi<30?"تشبع بيع 🟢":rsi>70?"تشبع شراء 🔴":"محايد",c:rsi<30?"#00c97a":rsi>70?"#ff4757":"#f0c040"},{n:"EMA9",v:e9.toFixed(1),s:price>e9?"فوق ✅":"تحت ❌",c:price>e9?"#00c97a":"#ff4757"},{n:"EMA21",v:e21.toFixed(1),s:price>e21?"صعودي ✅":"هبوطي ❌",c:price>e21?"#00c97a":"#ff4757"},{n:"دعم",v:`$${(Math.floor(price/50)*50-50)}`,s:"مستوى مهم",c:"#00c97a"},{n:"مقاومة",v:`$${(Math.ceil(price/50)*50+50)}`,s:"مستوى مهم",c:"#ff4757"}].map(ind=>(
          <div key={ind.n} style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:9,padding:"7px 10px",background:"rgba(255,255,255,0.03)",borderRadius:10}}>
            <Pill color={ind.c} sm>{ind.s}</Pill>
            <div style={{direction:"rtl"}}><span style={{color:"rgba(255,255,255,0.8)",fontSize:12}}>{ind.n}</span><span style={{color:"rgba(255,255,255,0.35)",fontSize:10,marginRight:6}}>{ind.v}</span></div>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ═══════════════════ PROFILE ═══════════════════
function ProfilePage({setPage}) {
  const [sub,setSub]=useState(null),[sel,setSel]=useState(null),[li,setLi]=useState(0),[vid,setVid]=useState(false);
  const [notifs,setNotifs]=useState({signals:true,news:true,perf:false,updates:true});
  const [settings,setSettings]=useState({lang:"ar",theme:"dark",sound:true,vibrate:true});
  const [twoFA,setTwoFA]=useState(false),[passChanged,setPassChanged]=useState(false);

  if(sub==="edu"&&sel!==null){
    const mod=EDU[sel];
    return(
      <div style={{display:"flex",flexDirection:"column",gap:14}}>
        <button onClick={()=>{setSel(null);setLi(0);setVid(false);}} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
        <GCard>
          <div style={{direction:"rtl",marginBottom:10}}><div style={{color:"#00c97a",fontWeight:700,fontSize:15}}>{mod.icon} {mod.title}</div></div>
          {!vid?(
            <div onClick={()=>setVid(true)} style={{position:"relative",borderRadius:14,overflow:"hidden",cursor:"pointer",background:"#000"}}>
              <img src={`https://img.youtube.com/vi/${mod.vid}/mqdefault.jpg`} alt="" style={{width:"100%",display:"block",opacity:0.7}}/>
              <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center"}}><div style={{width:58,height:58,borderRadius:"50%",background:"rgba(0,201,122,0.9)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26}}>▶</div></div>
            </div>
          ):(
            <div style={{position:"relative",width:"100%",paddingBottom:"56.25%",borderRadius:14,overflow:"hidden"}}>
              <iframe src={`https://www.youtube.com/embed/${mod.vid}?autoplay=1&rel=0`} style={{position:"absolute",inset:0,width:"100%",height:"100%",border:"none"}} allow="autoplay;encrypted-media" allowFullScreen title={mod.title}/>
            </div>
          )}
        </GCard>
        <Card>
          <div style={{direction:"rtl"}}>
            <div style={{display:"flex",gap:8,marginBottom:14}}>{mod.lessons.map((l,i)=><button key={i} onClick={()=>setLi(i)} style={{padding:"7px 15px",borderRadius:10,fontSize:12,fontFamily:"inherit",border:"none",cursor:"pointer",background:li===i?"#00c97a":"rgba(255,255,255,0.07)",color:li===i?"#000":"rgba(255,255,255,0.6)",fontWeight:700}}>درس {i+1}</button>)}</div>
            <div style={{color:"#00c97a",fontWeight:700,fontSize:13,marginBottom:10}}>{mod.lessons[li].t}</div>
            <div style={{background:"rgba(0,0,0,0.25)",borderRadius:12,padding:"14px",color:"rgba(255,255,255,0.78)",fontSize:13,lineHeight:2,whiteSpace:"pre-wrap",direction:"rtl"}}>{mod.lessons[li].c}</div>
            <div style={{display:"flex",justifyContent:"space-between",marginTop:14}}>
              {li>0?<button onClick={()=>setLi(i=>i-1)} style={{background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.12)",color:"rgba(255,255,255,0.6)",padding:"9px 18px",borderRadius:20,cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>← السابق</button>:<span/>}
              {li<mod.lessons.length-1?<button onClick={()=>setLi(i=>i+1)} style={{background:"rgba(0,201,122,0.15)",border:"1px solid rgba(0,201,122,0.3)",color:"#00c97a",padding:"9px 18px",borderRadius:20,cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>التالي →</button>:<button onClick={()=>{setSel(null);setLi(0);}} style={{background:"rgba(0,201,122,0.2)",border:"1px solid rgba(0,201,122,0.35)",color:"#00c97a",padding:"9px 18px",borderRadius:20,cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>✅ اكتمل</button>}
            </div>
          </div>
        </Card>
      </div>
    );
  }

  if(sub==="edu") return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <button onClick={()=>setSub(null)} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
      <GCard><div style={{color:"#00c97a",fontWeight:700,fontSize:15,direction:"rtl"}}>🎓 أكاديمية AN</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:12,marginTop:3,direction:"rtl"}}>فيديو يوتيوب + دروس نصية</div></GCard>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:12}}>
        {EDU.map((m,i)=>(
          <div key={m.id} onClick={()=>{setSel(i);setLi(0);setVid(false);}} style={{background:"#141e2e",border:`1px solid ${m.color}20`,borderRadius:14,padding:"14px 12px",cursor:"pointer",textAlign:"center"}}>
            <div style={{fontSize:28}}>{m.icon}</div>
            <div style={{color:"#fff",fontWeight:700,fontSize:12,marginTop:8,direction:"rtl",lineHeight:1.4}}>{m.title}</div>
            <div style={{marginTop:7}}><Pill color={m.color} sm>{m.level}</Pill></div>
            <div style={{fontSize:10,color:"rgba(255,255,255,0.35)",marginTop:5}}>{m.dur} • {m.lessons.length} دروس + فيديو</div>
            <div style={{marginTop:9,background:`${m.color}12`,borderRadius:10,padding:"5px",fontSize:11,color:m.color}}>▶ ابدأ الآن</div>
          </div>
        ))}
      </div>
    </div>
  );

  if(sub==="stats") return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <button onClick={()=>setSub(null)} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
      <GCard><div style={{color:"#00c97a",fontWeight:700,fontSize:15,direction:"rtl"}}>📊 إحصائياتي الشخصية</div></GCard>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:12}}>
        {[{l:"إجمالي الصفقات",v:"0",c:"#00c97a"},{l:"الصفقات الرابحة",v:"0",c:"#00c97a"},{l:"الصفقات الخاسرة",v:"0",c:"#ff4757"},{l:"نسبة النجاح",v:"0%",c:"#f0c040"},{l:"أيام التداول",v:"1",c:"#00d4ff"},{l:"الدروس المكتملة",v:"0",c:"#a78bfa"}].map(s=>(
          <Card key={s.l} style={{padding:"14px",textAlign:"center"}}>
            <div style={{fontSize:24,fontWeight:800,color:s.c}}>{s.v}</div>
            <div style={{fontSize:11,color:"rgba(255,255,255,0.45)",marginTop:4,direction:"rtl"}}>{s.l}</div>
          </Card>
        ))}
      </div>
      <Card><div style={{direction:"rtl",color:"rgba(255,255,255,0.4)",fontSize:12,lineHeight:1.8}}>📌 ابدأ التداول لتظهر إحصائياتك هنا<br/>سيتم تتبع أداءك تلقائياً مع كل صفقة</div></Card>
    </div>
  );

  if(sub==="notifs") return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <button onClick={()=>setSub(null)} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
      <GCard><div style={{color:"#00c97a",fontWeight:700,fontSize:15,direction:"rtl"}}>🔔 إعدادات الإشعارات</div></GCard>
      {[{k:"signals",l:"إشارات التداول",d:"إشعار عند ظهور إشارة جديدة"},{k:"news",l:"الأخبار الاقتصادية",d:"أخبار مؤثرة على الذهب"},{k:"perf",l:"تقارير الأداء",d:"ملخص يومي وأسبوعي"},{k:"updates",l:"تحديثات التطبيق",d:"آخر المميزات الجديدة"}].map(n=>(
      <Card key={n.k} style={{padding:"14px 16px"}}>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div onClick={()=>setNotifs(p=>({...p,[n.k]:!p[n.k]}))} style={{width:44,height:24,borderRadius:12,background:notifs[n.k]?"#00c97a":"rgba(255,255,255,0.1)",position:"relative",cursor:"pointer",transition:"background 0.3s",flexShrink:0}}>
            <div style={{position:"absolute",top:2,left:notifs[n.k]?22:2,width:20,height:20,borderRadius:"50%",background:"#fff",transition:"left 0.3s"}}/>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{color:"#fff",fontWeight:700,fontSize:13}}>{n.l}</div>
            <div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>{n.d}</div>
          </div>
        </div>
      </Card>
      ))}
    </div>
  );

  if(sub==="settings") return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <button onClick={()=>setSub(null)} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
      <GCard><div style={{color:"#00c97a",fontWeight:700,fontSize:15,direction:"rtl"}}>⚙️ إعدادات الحساب</div></GCard>
      {[{k:"sound",l:"الصوت",d:"تشغيل الأصوات عند الإشعارات"},{k:"vibrate",l:"الاهتزاز",d:"اهتزاز عند الإشعارات"}].map(s=>(
        <Card key={s.k} style={{padding:"14px 16px"}}>
          <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div onClick={()=>setSettings(p=>({...p,[s.k]:!p[s.k]}))} style={{width:44,height:24,borderRadius:12,background:settings[s.k]?"#00c97a":"rgba(255,255,255,0.1)",position:"relative",cursor:"pointer",transition:"background 0.3s",flexShrink:0}}>
              <div style={{position:"absolute",top:2,left:settings[s.k]?22:2,width:20,height:20,borderRadius:"50%",background:"#fff",transition:"left 0.3s"}}/>
            </div>
            <div style={{textAlign:"right"}}><div style={{color:"#fff",fontWeight:700,fontSize:13}}>{s.l}</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>{s.d}</div></div>
          </div>
        </Card>
      ))}
      <Card style={{padding:"14px 16px"}}>
        <div style={{color:"rgba(255,255,255,0.5)",fontSize:11,direction:"rtl",lineHeight:1.8}}>🌐 اللغة: العربية<br/>🎨 المظهر: داكن<br/>📱 الإصدار: 1.0.0</div>
      </Card>
    </div>
  );

  if(sub==="security") return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <button onClick={()=>setSub(null)} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
      <GCard><div style={{color:"#00c97a",fontWeight:700,fontSize:15,direction:"rtl"}}>🛡️ الأمان والخصوصية</div></GCard>
      <Card style={{padding:"14px 16px"}}>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div onClick={()=>setTwoFA(!twoFA)} style={{width:44,height:24,borderRadius:12,background:twoFA?"#00c97a":"rgba(255,255,255,0.1)",position:"relative",cursor:"pointer",transition:"background 0.3s",flexShrink:0}}>
            <div style={{position:"absolute",top:2,left:twoFA?22:2,width:20,height:20,borderRadius:"50%",background:"#fff",transition:"left 0.3s"}}/>
          </div>
          <div style={{textAlign:"right"}}><div style={{color:"#fff",fontWeight:700,fontSize:13}}>التحقق الثنائي 2FA</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>حماية إضافية لحسابك</div></div>
        </div>
      </Card>
      <Card style={{padding:"14px 16px",cursor:"pointer"}} onClick={()=>setPassChanged(true)}>
        <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span style={{color:passChanged?"#00c97a":"rgba(255,255,255,0.4)",fontSize:12}}>{passChanged?"✅ تم الطلب":"اضغط للتغيير"}</span>
          <div style={{textAlign:"right"}}><div style={{color:"#fff",fontWeight:700,fontSize:13}}>🔒 تغيير كلمة المرور</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>آخر تغيير: غير محدد</div></div>
        </div>
      </Card>
      <Card style={{padding:"14px"}}><div style={{color:"rgba(255,255,255,0.4)",fontSize:11,direction:"rtl",lineHeight:1.8}}>🔐 بياناتك مشفرة بالكامل<br/>👁️ لا نشارك بياناتك مع أطراف ثالثة<br/>🗑️ يمكنك حذف حسابك في أي وقت</div></Card>
    </div>
  );

  if(sub==="support") return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <button onClick={()=>setSub(null)} style={{background:"rgba(0,201,122,0.1)",border:"1px solid rgba(0,201,122,0.25)",color:"#00c97a",padding:"10px 16px",borderRadius:20,cursor:"pointer",fontSize:13,fontFamily:"inherit",direction:"rtl",textAlign:"right"}}>← العودة</button>
      <GCard><div style={{color:"#00c97a",fontWeight:700,fontSize:15,direction:"rtl"}}>❓ المساعدة والدعم</div></GCard>
      {[{q:"كيف أستخدم المستشار الذكي؟",a:"اذهب لقسم المستشار، ارفع صورة الشارت أو اكتب سؤالك مباشرة. الذكاء الاصطناعي سيحلل وضعك ويعطيك توصية مفصلة."},{q:"كيف تعمل الإشارات؟",a:"الإشارات مبنية على نظام EMA+RSI+MACD مع أنماط الشموع اليابانية. تتجدد كل ساعة تلقائياً."},{q:"هل الإشارات مضمونة 100%؟",a:"لا — لا يوجد في العالم ضمان 100% في التداول. الإشارات أداة مساعدة وليست قرار نهائي."},{q:"كيف أرفع التطبيق على جوالي؟",a:"افتح الموقع من المتصفح، اضغط 'مشاركة' ثم 'أضف إلى الشاشة الرئيسية' ليعمل كتطبيق."}].map((item,i)=>{
      const [open,setOpen]=useState(false);
      return(
        <Card key={i} style={{cursor:"pointer"}} onClick={()=>setOpen(!open)}>
          <div style={{direction:"rtl",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{color:"rgba(255,255,255,0.35)",fontSize:14}}>{open?"▲":"▼"}</span>
            <div style={{color:"#fff",fontWeight:700,fontSize:13,flex:1,textAlign:"right",marginRight:10}}>{item.q}</div>
          </div>
          {open&&<div style={{color:"rgba(255,255,255,0.65)",fontSize:12,lineHeight:1.7,marginTop:10,direction:"rtl",padding:"10px",background:"rgba(0,201,122,0.06)",borderRadius:10}}>{item.a}</div>}
        </Card>
      );
    })}
    <GCard style={{padding:"14px 16px"}}>
      <div style={{color:"rgba(255,255,255,0.6)",fontSize:12,direction:"rtl",lineHeight:1.8}}>📧 للتواصل المباشر:<br/><span style={{color:"#00c97a"}}>support@an-gold.com</span><br/>⏰ أوقات الدعم: 24/7</div>
    </GCard>
    </div>
  );

  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <GCard>
        <div style={{display:"flex",alignItems:"center",gap:14,direction:"rtl"}}>
          <div style={{width:60,height:60,borderRadius:"50%",background:"linear-gradient(135deg,#00c97a,#009955)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,flexShrink:0}}>👤</div>
          <div><div style={{color:"#fff",fontWeight:800,fontSize:18}}>مستخدم AN</div><div style={{color:"rgba(255,255,255,0.5)",fontSize:12,marginTop:2}}>عضو موثق ✅</div><div style={{display:"flex",gap:8,marginTop:8}}><Pill color="#f0c040" sm>⭐ 0 نقطة</Pill><Pill color="#00c97a" sm>مباشر</Pill></div></div>
        </div>
      </GCard>
      {[
        {icon:"🎓",title:"الأكاديمية التعليمية",desc:"تعلم التداول من الصفر",color:"#00c97a",action:"edu"},
        {icon:"📊",title:"إحصائياتي",desc:"متابعة أدائي الشخصي",color:"#00d4ff",action:"stats"},
        {icon:"🔔",title:"الإشعارات",desc:"إعدادات التنبيهات",color:"#a78bfa",action:"notifs"},
        {icon:"⚙️",title:"الإعدادات",desc:"إعدادات الحساب",color:"#f0c040",action:"settings"},
        {icon:"🛡️",title:"الأمان والخصوصية",desc:"حماية حسابك",color:"#ff9500",action:"security"},
        {icon:"❓",title:"المساعدة والدعم",desc:"تواصل مع الفريق",color:"#ff4757",action:"support"},
      ].map(item=>(
        <div key={item.title} onClick={()=>setSub(item.action)} style={{background:"#141e2e",border:`1px solid ${item.color}15`,borderRadius:14,padding:"13px 15px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span style={{color:"rgba(255,255,255,0.3)"}}>›</span>
          <div style={{flex:1,direction:"rtl",marginRight:10}}><div style={{color:"#fff",fontWeight:700,fontSize:13}}>{item.title}</div><div style={{color:"rgba(255,255,255,0.4)",fontSize:11,marginTop:2}}>{item.desc}</div></div>
          <div style={{width:42,height:42,borderRadius:11,background:`${item.color}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{item.icon}</div>
        </div>
      ))}
    </div>
  );
}

// ═══════════════════ MAIN APP ═══════════════════
export default function App() {
  const [page,setPage]=useState("home");
  const gold=useGoldPrice();
  const PAGES={
    home:<HomePage gold={gold} setPage={setPage}/>,
    advisor:<AdvisorPage price={gold.price}/>,
    signals:<SignalsPage candles={gold.candles} price={gold.price}/>,
    perf:<PerfPage/>,
    invest:<InvestPage/>,
    profile:<ProfilePage setPage={setPage}/>,
    chart:<ChartPage gold={gold}/>,
  };
  return(
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#0a1020;font-family:'Cairo',sans-serif;}
        @keyframes bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}
        ::-webkit-scrollbar{width:2px;height:2px;}
        ::-webkit-scrollbar-thumb{background:rgba(0,201,122,0.2);border-radius:4px;}
        button,input{font-family:'Cairo',sans-serif;}
        input::placeholder{color:rgba(0,201,122,0.35);}
      `}</style>
      <div style={{minHeight:"100vh",background:"#0a1020",color:"#fff",paddingBottom:72}}>
        <div style={{background:"rgba(8,14,24,0.97)",backdropFilter:"blur(20px)",borderBottom:"1px solid rgba(0,201,122,0.1)",padding:"12px 18px",display:"flex",justifyContent:"space-between",alignItems:"center",position:"sticky",top:0,zIndex:100}}>
          <div style={{background:"rgba(0,201,122,0.15)",border:"1px solid rgba(0,201,122,0.3)",color:"#00c97a",padding:"4px 10px",borderRadius:20,fontSize:11,fontWeight:700}}>⭐ 0 +</div>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{textAlign:"right"}}><div style={{color:"#00c97a",fontWeight:900,fontSize:22,letterSpacing:2}}>AN</div><div style={{color:"rgba(255,255,255,0.25)",fontSize:8,direction:"rtl"}}>منصة التداول الذكي</div></div>
            <div style={{width:34,height:34,borderRadius:"50%",background:"linear-gradient(135deg,#00c97a,#009955)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>📊</div>
          </div>
          <div onClick={()=>setPage("profile")} style={{width:34,height:34,borderRadius:"50%",background:"rgba(255,255,255,0.06)",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontSize:16}}>👤</div>
        </div>
        <div style={{padding:"14px 13px",maxWidth:480,margin:"0 auto"}}>{PAGES[page]||PAGES["home"]}</div>
        <div style={{position:"fixed",bottom:0,left:0,right:0,background:"rgba(6,10,18,0.97)",backdropFilter:"blur(20px)",borderTop:"1px solid rgba(0,201,122,0.1)",display:"flex",justifyContent:"space-around",padding:"7px 0 11px",zIndex:100}}>
          {NAV.map(n=>(
            <button key={n.id} onClick={()=>setPage(n.id)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3,background:"none",border:"none",cursor:"pointer",padding:"3px 7px"}}>
              <span style={{fontSize:page===n.id?20:17,transition:"all 0.25s",filter:page===n.id?"drop-shadow(0 0 6px rgba(0,201,122,0.7))":"none"}}>{n.icon}</span>
              <span style={{fontSize:9,color:page===n.id?"#00c97a":"rgba(255,255,255,0.28)",fontWeight:page===n.id?700:400,direction:"rtl"}}>{n.label}</span>
              {page===n.id&&<div style={{width:16,height:2,background:"#00c97a",borderRadius:2}}/>}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
